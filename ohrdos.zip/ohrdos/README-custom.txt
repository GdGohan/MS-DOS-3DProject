------------------------------------------------------------
 O.H.R.RPG.C.E Editor         (August 03 2006 Hasta-la-qb+)
------------------------------------------------------------
Official Hamster Republic RPG Construction Engine

---

To get started, read http://HamsterRepublic.com/ohrrpgce/

---

Please see WHATSNEW.TXT for revision information.

---
DISTRIBUTION

The OHRRPGCE is free software under the terms of the GPL
Please read LICENSE.txt for more information. Visit
http://HamsterRepublic.com/ohrrpgce/source.php to download
the source code.

Any .RPG files you create are yours to distribute as you please.
You may freely distribute GAME.EXE, with your .RPG files provided
that you include a copy of LICENSE-binary.txt so that people will
know where to get the source code. No other files are needed for
people to play your RPG files

If you have questions, read the FAQ at
http://HamsterRepublic.com/ohrrpgce/faq.php

---

Report bugs at: http://HamsterRepublic.com/ohrrpgce/buglist.php

---
MUSIC

A small assortment of Public-Domain music has also been included for you to
use for free if you do not want to compose your own music. Please read
MUSIC.TXT for more info on the songs.

---
Spiffy, Spiffy! Enjoy the editor.

                                            James Paige
                                            Hamster Republic Productions
                                            http://HamsterRepublic.com/
